package com.grindrplus.core

object Constants {
    const val NEWLINE = "GRINDRPLUS_NEWLINE"
    const val GRINDR_PACKAGE_NAME = "com.grindrapp.android"
}